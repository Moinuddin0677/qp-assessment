export interface GroceryItem {
    id: number;
    name: string;
    price: number;
    inventory: number;
  }
  